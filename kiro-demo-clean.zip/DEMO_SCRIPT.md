# Kiro IDE Demo Script

## Core Strategies

Throughout the demo, emphasize these principles:

1. Work with and through the agent: This keeps world states in sync — no "oh the file changed, let me re-read it" moments
2. Harness engineering: Let the agent work longer without interruption via spec-driven development, upfront context building and automated verification (tests).
3. Build in iteration loops: Letting agents take a second look on requirements, design, and intermediate results means better results (test-time compute). Separate context windows make this even more powerful: one agent can cause a bug, another using the same model can find it — just like engineers reviewing each other's code

---

## Setup

- Check out the `kiro-demo-clean` branch — a bare full-stack app with no docs, no scripts, no steering, no tests
- If you can, use speech-to-text software AI interactions throughout the demo
- **Set model to Opus 4.6**
- Ensure **Vibe** mode is selected in the chat pane
- Ensure you have a current version of node.js and npm

## Act 1: Foundational Setup

### 1.1 Create Steering Docs

Ask Kiro to analyze the codebase and create foundational steering files.

> Kiro Standard Pane > Agent Steering & Skills > (+) > Project Steering Files

Let Kiro explore the code and generate all three. Don't interrupt — let it work through the full analysis.

### 1.2 Set Up The Project

- Ask Kiro to install and run the project.

This will show Kiro's ability to manage long-running processes — the servers stay up in the background while you continue chatting.

- Ask Kiro to create a dev startup script that runs both frontend and backend.

> Create a script that starts both the backend and frontend servers and register it in the package.json. Make it so it stores both server and frontend logs to a log file that you can use for debugging.

- Bonus: Ask Kiro to use web search to add console logging:

> Research on the web if vite has a feature to capture browser error logs so we can add that to our dev script.

Kiro might find https://github.com/mitsuhiko/vite-console-forward-plugin to accomplish the task. 

Why are we doing this? To give our agent the ability to understand and debug our app easily.

---

## Act 2: Create Reviewable Artifacts

### 2.1 Exploratory Walkthrough with Playwright 

Install the browser power by clicking on the Kiro pane with the lightning, click "Add custom Power", "Import power from Github":

> https://github.com/486/browser

Ask Kiro to use the browser power, start video recording, and do an exploratory walkthrough — browse sessions, use the search filters, view a session detail, sign in, add sessions to the schedule, check the My Schedule page, and test pagination. Save the recording.

This produces a video artifact that can be shared and reviewed.

While you are using MCP servers and other tools, start to whitelist commands that are usually safe to run - this helps to reduce interruptions.

### 2.2 Set Up Tests

> "Create Playwright E2E tests for the walkthrough you just did. Add test commands to the package.json."

Let Kiro scaffold the test infrastructure.

### 2.2 Update Steering to Reflect Verification

> "Update tech.md to document how to verify this app works — include the Playwright CLI walkthrough approach we just used, and the test commands."

Kiro updates its own steering docs to reflect the new capabilities. This is the flywheel — the more you build with Kiro, the better its context gets.

---

## Act 3: Spec-Driven Development

### 3.1 Optional: Build Prototypes First

Before committing to the full implementation, validate the tech:

> Before we finalize the design, let's build a quick prototype to verify ...

This is a part of the tracer bullet approach — prove the unknown parts work before building the full thing.

### 3.2 Start a Spec

Pick a feature to build.

Let Kiro create the requirements document. Don't rush — let it think through the full scope.

### 3.3 Optional: Use Kiro AWS Power for Architecture

Activate the AWS infrastructure power to refine the cloud architecture, if needed for your spec.

> Use the AWS infrastructure power to refine my architecture.

The power brings in current CDK docs, best practices, and can validate CloudFormation templates.

### 3.4 Challenge the Requirements and the Design

After Kiro produces the requirements and design docs, push back:

> Review the requirements document. Do you see any gaps, ambiguities, or contradictions? Is there anything you'd like to ask me for clarification? Ask one question at a time.

This forces Kiro into a critical review mode. Answer each question, let it update the doc, then ask again until it's satisfied. This is test-time compute in action — more iteration, better result.

### 3.5 Create comprehensive test scenarios

Ask Kiro to spin up a subagent as the QA tester who should come up with multiple unit, integration and e2e test scenarios for the spec. 

### 3.6 Adversarial Review with Subagent

Run an adversarial reviewer subagent. It should review the requirements and design documents, looking for security issues, scalability concerns, missing edge cases, and implementation risks. Have it write its review as a markdown file.

This leverages the separate-context-window principle. The reviewer subagent has fresh eyes on the same material — it will catch things the authoring agent missed, just like a code review from a colleague.

### 3.7 Improve the Task List

After the review, refine the implementation plan:

> Restructure the task list to use tracer bullets instead of horizontal layers. Each task should deliver a thin vertical slice that's independently testable.

Tracer bullets over horizontal implementation means you get working, verifiable increments instead of building all the infrastructure first and hoping it works when you plug the app in.

---

## Act 4: Implementation

Let Kiro work through the tasks. You can start one task after the other or use the button to run all tasks.

Kiro automatically handles context management by running each task in a fresh session which only injects the foundational steering files. [Needle-in-a-haystack benchmarks show that Opus 4.6 is significantly better](https://www.anthropic.com/news/claude-opus-4-6) at working with a full context window - Opus 4.6 scores 76%, whereas Sonnet 4.5 scores just 18.5%. Still, larger windows can make the LLM slower to respond, and you do not want to hit context compaction, so Kiro is giving you the best, automated experience out of the box.

---

## Key Takeaways

- **Steering docs are the flywheel**: The more you build, the better Kiro's context gets, the better the next feature goes
- **Specs separate thinking from doing**: Requirements and design happen in one phase, implementation in another — less thrashing
- **Subagents bring fresh perspective**: Same model, different context window, catches different things
- **Tracer bullets over horizontal layers**: Every task produces something verifiable
- **Think like product / engineering manager**: Kiro is the engineer carrying out the task. Your job is to give it enough context and keep it honest through verification.
- **Reviewable artifacts as proof**: Playwright CLI recordings show the app actually works, not just that tests pass. Instead of sifting through the code, Mermaid diagrams explain codebases and processes visually.
