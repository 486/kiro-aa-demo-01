# Kiro IDE Demo Script

## Core Strategies

Throughout the demo, emphasize these principles:

1. Work with and through the agent: This keeps world states in sync — no "oh the file changed, let me re-read it" moments
2. Harness engineering: Let the agent work longer without interruption via spec-driven development, upfront context building and automated verification (tests).
3. Build in iteration loops: Letting agents take a second look on requirements, design, and intermediate results means better results (test-time compute). Separate context windows make this even more powerful: one agent can cause a bug, another using the same model can find it — just like engineers reviewing each other's code

---

## Setup

- If you can, use speech-to-text software AI interactions throughout the demo
- Ensure you have a current version of node.js and npm

## Act 1: Foundational Setup

### 1.1 Create Steering Docs

Ask Kiro to analyze the codebase and create foundational steering files:

`Kiro Standard Pane > Agent Steering & Skills > (+) > Project Steering Files`

Let Kiro explore the code and generate all three. Don't interrupt — let it work through the full analysis.

### 1.2 Set Up The Project

- Ask Kiro to install and run the project.

> Install and run this project.

This will show Kiro's ability to manage long-running processes — the servers stay up in the background while you continue chatting.

- Ask Kiro to create a dev startup script that runs both frontend and backend.

> Create a script that starts both the backend and frontend servers and register it in the package.json. Make it so it stores both server and frontend logs to a log file that you can use for debugging.

- Kiro builds the script and provides the instructions to run it to you, but not run it on its own. This is where we nudge our agent into a feedback loop by asking it to execute the script:

> Run the script now.

This is how we keep the world synced between us and the agent - by doing work through the agent and letting it see the results and correct any issues.

- Bonus: Ask Kiro to use web search to add console logging:

> Research on the web if vite has a feature to capture browser error logs so we can add that to our dev script.

Kiro might find https://github.com/mitsuhiko/vite-console-forward-plugin to accomplish the task. 

Why are we doing this? To give our agent the ability to understand and debug our app easily.

Now we want to persist this as part of the primary development workflow for the agent.

> Make the dev script part of our main development workflow in the steering docs.

---

## Act 2: Create Reviewable Artifacts

### 2.1 Exploratory Walkthrough with Playwright 

Install the browser power by clicking on the Kiro pane with the lightning, click "Add custom Power", "Import power from Github":

> https://github.com/486/browser

Ask Kiro to:

> Use the browser power, and make a video recording of an exploratory walkthrough — browse sessions, use the search filters, view a session detail, sign in, add sessions to the schedule, check the My Schedule page, and test pagination.

This produces a video artifact that can be shared and reviewed. Why is this important? We want to give our agent "eyes and hands" - the more it can do and "see" on its own, the easier it can fulfill a task autonomously and get feedback if it reached the goal. 

While you are using MCP servers and other tools, start to whitelist commands that are usually safe to run - this helps to reduce interruptions.

### 2.2 Set Up Tests

> Code Playwright tests for the walkthrough you just did. Add test commands to the package.json.

This is how we turn manual, slow explorations into repeatable end-to-end tests. Because the agent just used the app, it's now easy for it to write it as a test. 

Again, to make this a feedback loop, ask Kiro to actually run the tests, if it didn't do so on its own.

> Run the tests.

### 2.2 Update Steering to Reflect Verification

> Update the development workflow in the steering docs with how to verify this app works — include the Playwright CLI walkthrough approach, codification into repeatable tests and the test commands.

Kiro updates its own steering docs to reflect the new capabilities. This is the flywheel — you build with Kiro and persist common development workflows and guidelines in its steering docs (you can also write skills to encode these workflows).

We consciously didn't dive into unit and integration tests - the focus here was to show how the agent can act as an end user to identify complex issues end-to-end.

---

## Act 3: Spec-Driven Development

### 3.1 Optional: Build Prototypes First

Before committing to the full implementation, validate the tech:

> Before we finalize the design, let's build a quick prototype to verify ...

This is just a reminder that spec-driven development allows for quick throwaway prototypes without a detailed plan. 

### 3.2 Start a Spec

First, let's create a new session by hitting the `+` in the sidebar. Under "Start with a workflow", click "Spec".

Pick a feature to build.

> Help me build a session recommender feature.

Kiro will ask if this is a feature, a bugfix or a quick spec. Choose feature. Then it will ask whether to start with requirements or technical design. Choose requirements. Kiro will start writing the requirements document. 

Note that when working on a real project, we would have given Kiro way more information upfront about what we want to achieve. If we keep it so short, it will "vibe spec". 

### 3.3 Challenge the Requirements and the Design

With any agent, after it produces the requirements and design docs, typically you'd ask it to take another look at its work. In Kiro, there is a handy shortcut for this common action - just click "Analyze Requirements" at the bottom of its response after it finished the requirements. 

This puts Kiro into a critical review mode. It will ask you questions when it detects gaps in the requirements, and update them based on your answers. This is test-time compute in action — more iteration, better result.

### 3.4 Generate Design and Task List

As with the requirements, you'd read the design and converse with Kiro to make changes. 

### 3.5 Improve the Task List

After the task list is created, there are some common refinements you'd want to make:

> Restructure the task list to use tracer bullets instead of horizontal layers. Each task should deliver a thin vertical slice that's independently testable. Ensure each tasks follows TDD - Write the test first. Watch it fail. Write minimal code to pass. Add a task to deliver a video demoing the feature. 

Tracer bullets over horizontal implementation means you get working, verifiable increments instead of building all the infrastructure first and hoping it works when you plug the app in. Tests-first answers "What should this do?". Tests created after the code are biased by the agent's implementation - they test what it built, not what's required. Asking Kiro to deliver a video helps us to quickly understand if it has built the right thing.

### 3.6 Build the Feature

Go to the tasks and hit "Run all tasks", then "Run required tasks".

Kiro automatically handles context management by running each task in a fresh session which only injects the foundational steering files. [Needle-in-a-haystack benchmarks show that newer models like Opus 4.6 are significantly better](https://www.anthropic.com/news/claude-opus-4-6) at working with a full context window - Opus 4.6 scores 76%, whereas Sonnet 4.5 scores just 18.5%. Still, larger windows can make the LLM slower to respond, and you do not want to hit context compaction, so Kiro is giving you the best, automated experience out of the box.

### 3.7 Code Review with Subagent

After Kiro is finished with coding, we wll run a reviewer as a subagent.

This leverages the separate-context-window principle. The reviewer subagent has fresh eyes on the same material — it will catch things the authoring agent missed, just like a code review from a colleague.

Ask Kiro:

```
    Run a subagent as code reviewer with the following prompt:

    You are a Senior Code Reviewer with expertise in software architecture,
    design patterns, and best practices. Your job is to review completed work
    against its plan or requirements and identify issues before they cascade.

    ## What Was Implemented

    [DESCRIPTION]

    ## Requirements / Plan

    [PLAN_OR_REQUIREMENTS]

    ## What to Check

    **Plan alignment:**
    - Does the implementation match the plan / requirements?
    - Are deviations justified improvements, or problematic departures?
    - Is all planned functionality present?

    **Code quality:**
    - Clean separation of concerns?
    - Proper error handling?
    - Type safety where applicable?
    - DRY without premature abstraction?
    - Edge cases handled?

    **Architecture:**
    - Sound design decisions?
    - Reasonable scalability and performance?
    - Security concerns?
    - Integrates cleanly with surrounding code?

    **Testing:**
    - Tests verify real behavior, not mocks?
    - Edge cases covered?
    - Integration tests where they matter?
    - All tests passing?

    **Production readiness:**
    - Migration strategy if schema changed?
    - Backward compatibility considered?
    - Documentation complete?
    - No obvious bugs?

    ## Calibration

    Categorize issues by actual severity. Not everything is Critical.
    Acknowledge what was done well before listing issues — accurate praise
    helps the implementer trust the rest of the feedback.

    If you find significant deviations from the plan, flag them specifically
    so the implementer can confirm whether the deviation was intentional.
    If you find issues with the plan itself rather than the implementation,
    say so.

    ## Output Format

    ### Strengths
    [What's well done? Be specific.]

    ### Issues

    #### Critical (Must Fix)
    [Bugs, security issues, data loss risks, broken functionality]

    #### Important (Should Fix)
    [Architecture problems, missing features, poor error handling, test gaps]

    #### Minor (Nice to Have)
    [Code style, optimization opportunities, documentation polish]

    For each issue:
    - File:line reference
    - What's wrong
    - Why it matters
    - How to fix (if not obvious)

    ### Recommendations
    [Improvements for code quality, architecture, or process]

    ### Assessment

    **Ready to merge?** [Yes | No | With fixes]

    **Reasoning:** [1-2 sentence technical assessment]

    ## Critical Rules

    **DO:**
    - Categorize by actual severity
    - Be specific (file:line, not vague)
    - Explain WHY each issue matters
    - Acknowledge strengths
    - Give a clear verdict

    **DON'T:**
    - Say "looks good" without checking
    - Mark nitpicks as Critical
    - Give feedback on code you didn't actually read
    - Be vague ("improve error handling")
    - Avoid giving a clear verdict

```

---

## Key Takeaways

- **Steering docs are the flywheel**: The better your steering docs, the better Kiro's context gets, the better the next feature goes
- **Specs separate thinking from doing**: Requirements and design happen in one phase, implementation in another
- **Subagents bring fresh perspective**: Same model, different context window, catches different things
- **Tracer bullets over horizontal layers**: Every task produces something verifiable
- **Think like product / engineering manager**: Kiro is the engineer carrying out the task. Your job is to give it enough context and keep it honest through verification.
- **Reviewable artifacts as proof**: Playwright CLI recordings show the app actually works, not just that tests pass. Instead of sifting through the code, Mermaid diagrams explain codebases and processes visually.
