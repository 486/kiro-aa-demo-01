# re:Invent Session Catalog

A full-stack web app for browsing and managing AWS re:Invent conference sessions.
